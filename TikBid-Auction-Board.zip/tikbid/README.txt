TikBid Brainrot Auction Board prototype

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, or another modern browser.
3. Place demo bids, create multiple brainrot lots, choose a custom duration, and test the end-of-auction winner animation.

NEW FEATURES
- Auction-board style listing layout.
- Create between 1 and 25 lots at once.
- Select Garama, Dragoncaneloni, Skibidi, Meowl, Strawberryellyphant, or a custom brainrot name.
- Set duration with custom hours, minutes, and seconds (minimum 1 second).
- Closed auctions show a winner banner and end animation.
- Host can locally confirm a vouch after manually checking the TikTok LIVE comment.

LIMITATIONS
This is a local front-end demo. Listings, bids, vouches, and timers are not shared across users or saved to a server. TikTok links open TikTok but do not read LIVE comments or gifts. A real public app needs a backend, account authentication, server-side timing and bid validation, persistent storage, and approved TikTok API access where available. Demo coins are not real currency and are not TikTok Coins or Gifts.
